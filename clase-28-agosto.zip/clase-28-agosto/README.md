# CLASE 28 AGOSTO 

A Pen created on CodePen.io. Original URL: [https://codepen.io/CAMILA-GRIMANESA-PLAZA-RUBIO/pen/VwJXXgQ](https://codepen.io/CAMILA-GRIMANESA-PLAZA-RUBIO/pen/VwJXXgQ).

